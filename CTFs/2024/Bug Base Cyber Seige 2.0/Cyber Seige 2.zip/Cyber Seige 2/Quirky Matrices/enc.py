

def prepare_text(text, block_size):
    padding = (block_size - len(text) % block_size) % block_size
    text = text.upper() + 'A' * padding
    return text

def text_to_matrix(text, block_size):
    matrix = [ord(char) - ord('A') for char in text]
    return [matrix[i:i+block_size] for i in range(0, len(matrix), block_size)]

def matrix_to_text(matrix):
    text = ''.join(chr(value+ord('A')) for row in matrix for value in row)
    return text

def encrypt(plaintext, key_matrix):
    block_size = len(key_matrix[0])
    plaintext = prepare_text(plaintext, block_size)

    plaintext_matrix = text_to_matrix(plaintext, block_size)  


    ciphertext_matrix = [[sum((ord(key_matrix[i][k])-ord('A'))*plaintext_matrix[j][k] for k in range(3))%26 for i in range(3)] for j in range(len(plaintext_matrix))]

    ciphertext = matrix_to_text(ciphertext_matrix)
    return ciphertext


def main(toencrypt):
    #key matrix (3x3 matrix)
    key_matrix = [REDACTED]

    ciphertext = encrypt(toencrypt, key_matrix)
    return ciphertext
    

if __name__ == "__main__":
    flag = '[REDACTED]'
    print(f"This is what you need to decode: {main(flag)}")
    while True:
        toencrypt = input("Enter your text: ")
        print(f"Encrypted: main(toencrypt)")
